4th Module - Intro to Bioinformatics
Bruno Azenha Goncalves
ICMC - USP

---- Exercise 1 ----

In this exercise, I am generating random sequences given the Hidden States and
comparing the number of Matches with the total number of trials to get the percentage.

The experiment is run 100 million times. I get the time that the resulting sequence was
"01011101001" and divide by 100 million to get the chance of that sequence happening.

Then I run this algorithm 10 times, writing down the results and taking the average.

The average probability was 4.57 * 10^(-5)


---- Exercise 2 ----

First thing to do was to save the OR21 information from the 347OR,fasta file into another
one, for easy access.


