#!/bin/bash

./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 100
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 250
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 500
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 750
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 1000
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 1250
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 1500
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 1750
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 3000
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 5000
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 7500
./script2.py ./Genomes/homoGenome.fasta ./Genomes/chimpGenome.fasta 10000